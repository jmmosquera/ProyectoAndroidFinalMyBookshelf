package iezv.jmm.mybookshelfproject.Book;

import android.app.Dialog;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.SystemClock;
import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.Spinner;

import java.util.Calendar;

import iezv.jmm.mybookshelfproject.Book.DatePicker;
import iezv.jmm.mybookshelfproject.R;
import iezv.jmm.mybookshelfproject.SQLite.BooksManager;
import iezv.jmm.mybookshelfproject.SQLite.Helper;

public class AddBook extends AppCompatActivity {

    private android.support.design.widget.TextInputEditText title;
    private android.support.design.widget.TextInputLayout titleLayout;
    private android.support.design.widget.TextInputEditText author;
    private android.support.design.widget.TextInputLayout authorLayout;
    private android.widget.Spinner readingStatus;
    private android.widget.ImageView uploadCover;
    private android.support.design.widget.TextInputEditText summary;
    private android.widget.Button saveBook;
    private android.support.design.widget.TextInputEditText startReading;
    private android.support.design.widget.TextInputLayout startReadingLayout;
    private android.support.design.widget.TextInputEditText endReading;
    private android.support.design.widget.TextInputLayout endReadingLayout;
    private int selected = 0;
    private Dialog rateBook;
    int rating;
    Helper helper = new Helper(AddBook.this);
    BooksManager manager = new BooksManager(AddBook.this);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_book);
        this.endReadingLayout = (TextInputLayout) findViewById(R.id.endReadingLayout);
        this.endReading = (TextInputEditText) findViewById(R.id.endReading);
        this.startReadingLayout = (TextInputLayout) findViewById(R.id.startReadingLayout);
        this.startReading = (TextInputEditText) findViewById(R.id.startReading);
        this.saveBook = (Button) findViewById(R.id.saveBook);
        this.summary = (TextInputEditText) findViewById(R.id.summary);
        this.uploadCover = (ImageView) findViewById(R.id.uploadCover);
        this.readingStatus = (Spinner) findViewById(R.id.readingStatus);
        this.authorLayout = (TextInputLayout) findViewById(R.id.authorLayout);
        this.author = (TextInputEditText) findViewById(R.id.author);
        this.titleLayout = (TextInputLayout) findViewById(R.id.titleLayout);
        this.title = (TextInputEditText) findViewById(R.id.title);



        newBook();
    }

    public void buttonHandlerSetA(){
        readingStatus.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selected = readingStatus.getSelectedItemPosition();
                if(selected>1){
                    endReadingLayout.setVisibility(View.VISIBLE);
                }else{
                    endReadingLayout.setVisibility(View.INVISIBLE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        saveBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                if(selected>1){
                    rateBook = new Dialog(AddBook.this, R.style.FullHeightDialog);
                    rateBook.setContentView(R.layout.rate_book);
                    rateBook.setCancelable(true);
                    final RatingBar rateBookRatingbar = rateBook.findViewById(R.id.rateBookRatingbar);

                    Button rateBookButton = rateBook.findViewById(R.id.rateBookButton);
                    rateBookButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            rateBook.dismiss();
                            rating = Math.round(rateBookRatingbar.getRating());
                        }
                    });
                    rateBook.show();

                }else{

                }

                Book book = new Book(0, title.getText().toString(), author.getText().toString(), null, selected, startReading.getText().toString(), endReading.getText().toString(), rating, summary.getText().toString());
                storeBook(book);

            }
        });

        startReading.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DialogFragment datepicker = new DatePicker();
                datepicker.show(getSupportFragmentManager(), "datepicker");

            }
        });
    }

    public void storeBook(Book book){
        StoreBook sb = new StoreBook(book);
        sb.execute();
    }

    public class StoreBook extends AsyncTask<Integer, Integer, Integer>{

        private Book book;

        StoreBook(Book book){
            this.book = book;
        }

        @Override
        protected Integer doInBackground(Integer... integers) {

            Book storedBook = new Book();

            manager.open();

            long id = manager.insert(storedBook);
            book.setId(id);
            manager.update(book);

            return null;
        }
    }

    public void buttonHandlerSetB(){
        readingStatus.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selected = readingStatus.getSelectedItemPosition();
                if(selected>1){
                    endReadingLayout.setVisibility(View.VISIBLE);
                }else{
                    endReadingLayout.setVisibility(View.INVISIBLE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        saveBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(selected>1){
                    rateBook = new Dialog(AddBook.this, R.style.FullHeightDialog);
                    rateBook.setContentView(R.layout.rate_book);
                    rateBook.setCancelable(true);
                    RatingBar rateBookRatingbar = rateBook.findViewById(R.id.rateBookRatingbar);

                    Button rateBookButton = rateBook.findViewById(R.id.rateBookButton);
                    rateBookButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Book book = new Book(0, title.getText().toString(), author.getText().toString(), null, selected, startReading.getText().toString(), endReading.getText().toString(), rating, summary.getText().toString());
                            storeBook(book);
                            rateBook.dismiss();
                        }
                    });
                    rateBook.show();

                }else{
                    Book book = new Book(0, title.getText().toString(), author.getText().toString(), null, selected, startReading.getText().toString(), endReading.getText().toString(), 0, summary.getText().toString());
                    storeBook(book);
                }
            }
        });

        startReading.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DialogFragment datepicker = new DatePicker();
                datepicker.show(getSupportFragmentManager(), "datepicker");

            }
        });
    }

    public void getDate(String date){
        startReading.setText(date);
        startReading.setTextColor(getResources().getColor(R.color.colorAccent));
    }

    public void changeColorBriefly(){
        int editTextColour = 0;
        TypedArray themeArray = AddBook.this.getTheme().obtainStyledAttributes(new int[] {android.R.attr.editTextColor});
        try {
            int index = 0;
            int defaultColourValue = 0;
            editTextColour = themeArray.getColor(index, defaultColourValue);
        }
        finally
        {
            themeArray.recycle();
        }

        int counter = 200;

        try{
            do{

                counter--;
                SystemClock.sleep(1);
            }while(counter!=0);
        }catch(Exception e){
            e.toString();
        }finally {
            startReading.setTextColor(editTextColour);
        }
    }


    public void newBook(){
        buttonHandlerSetA();
        final Calendar c = Calendar.getInstance();
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH);
        int day = c.get(Calendar.DAY_OF_MONTH);
        String date = day+"/"+month+"/"+year;
        startReading.setText(date);
    }
}
