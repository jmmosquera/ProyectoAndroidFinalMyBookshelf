package iezv.jmm.mybookshelfproject.SQLite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.util.ArrayList;
import java.util.List;

import iezv.jmm.mybookshelfproject.Book.Book;

public class BooksManager {

    private Helper dbh;
    private SQLiteDatabase db;

    public BooksManager(Context c){dbh = new Helper(c);}

    public void open() {db = dbh.getWritableDatabase();}

    public void openRead() {db = dbh.getReadableDatabase();}

    public void close() {dbh.close();}

    public long insert(Book book){
        ContentValues values = new ContentValues();
        values.put(Contract.BookTable.IDCLOUD, book.getIdCloud());
        values.put(Contract.BookTable.TITLE, book.getTitle());
        values.put(Contract.BookTable.AUTHOR, book.getAuthor());
        values.put(Contract.BookTable.COVER, book.getCoverByteArray());
        values.put(Contract.BookTable.READINGSTATUS, book.getReadingStatus());
        values.put(Contract.BookTable.STARTDATE, book.getStartDate());
        values.put(Contract.BookTable.ENDDATE, book.getEndDate());
        values.put(Contract.BookTable.RATING, book.getRating());
        values.put(Contract.BookTable.SUMMARY, book.getSummary());

        long id = db.insert(Contract.BookTable.TABLE, null, values);

        return id;
    }

    public int delete(Book book){
        String condition = Contract.BookTable._ID + " = ?";
        String[] args = { book.getId() + ""};
        int count = db.delete(Contract.BookTable.TABLE, condition, args);
        return count;
    }

    public int update(Book book){
        ContentValues values = new ContentValues();

        values.put(Contract.BookTable.IDCLOUD, book.getIdCloud());
        values.put(Contract.BookTable.TITLE, book.getTitle());
        values.put(Contract.BookTable.AUTHOR, book.getAuthor());
        //values.put(Contract.BookTable.COVER, book.getCover());
        values.put(Contract.BookTable.READINGSTATUS, book.getReadingStatus());
        values.put(Contract.BookTable.STARTDATE, book.getStartDate());
        values.put(Contract.BookTable.ENDDATE, book.getEndDate());
        values.put(Contract.BookTable.RATING, book.getRating());
        values.put(Contract.BookTable.SUMMARY, book.getSummary());

        String condition = Contract.BookTable._ID + " = ?";
        String[] args = { book.getId() + ""};

        int count = db.update(Contract.BookTable.TABLE, values, condition, args);

        return count;
    }

    public Cursor getCursor(){
        Cursor cursor = db.query(Contract.BookTable.TABLE, null, null, null, null, null, null);
        return cursor;
    }

    public Book getRow(Cursor c){
        Book book = new Book();
        book.setId(c.getLong(0));
        book.setIdCloud(c.getString(1));
        book.setTitle(c.getString(2));
        book.setAuthor(c.getString(3));
        byte[] byteArray = c.getBlob(4);
        book.setCover(BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length));
        book.setReadingStatus(c.getInt(5));
        book.setStartDate(c.getString(6));
        book.setEndDate(c.getString(7));
        book.setRating(c.getInt(8));
        book.setSummary(c.getString(9));

        return book;
    }

    public Book get(long id){
        String[] proyection = {Contract.BookTable._ID, Contract.BookTable.IDCLOUD, Contract.BookTable.TITLE,
                Contract.BookTable.AUTHOR, Contract.BookTable.COVER, Contract.BookTable.READINGSTATUS,
                Contract.BookTable.STARTDATE, Contract.BookTable.ENDDATE, Contract.BookTable.RATING, Contract.BookTable.SUMMARY};
        String where = Contract.BookTable._ID+" = ?";
        String[] parameters = new String[] {id+""};
        String groupby = null;
        String having = null;
        String orderby = null;

        Cursor c = db.query(Contract.BookTable.TABLE, proyection, where, parameters, groupby, having, orderby);

        Book book = getRow(c);

        c.close();

        return book;
    }

    //Get específicos.

    public List<Book> select(String condition){
        List<Book> lb = new ArrayList<Book>();
        Cursor c = db.query(Contract.BookTable.TABLE, null, condition, null, null, null, null);
        Book book;
        while(c.moveToNext()){
            book = getRow(c);
            lb.add(book);
        }

        c.close();
        return lb;
    }

}
