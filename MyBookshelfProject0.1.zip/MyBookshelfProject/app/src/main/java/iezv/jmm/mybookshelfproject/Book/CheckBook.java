package iezv.jmm.mybookshelfproject.Book;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import iezv.jmm.mybookshelfproject.Book.Cover;
import iezv.jmm.mybookshelfproject.R;

public class CheckBook extends AppCompatActivity {

    private Book currentBook;
    private Toolbar toolbar;
    private android.support.design.widget.CollapsingToolbarLayout toolbarlayout;
    private android.support.design.widget.AppBarLayout appbar;
    private FloatingActionButton fab;
    private Button zoomIn;
    private TextView startDate;
    private TextView endDate;
    private TextView etReadingStatus;
    private RatingBar ratingBar;
    private TextView author;
    private TextView summary;
    private ImageView cover;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.check_book);
        this.fab = (FloatingActionButton) findViewById(R.id.fab);
        this.appbar = (AppBarLayout) findViewById(R.id.app_bar);
        this.toolbarlayout = (CollapsingToolbarLayout) findViewById(R.id.toolbar_layout);
        this.toolbar = (Toolbar) findViewById(R.id.toolbar);
        this.cover = findViewById(R.id.cover);
        loadExampleBook();
        toolbar.setTitle(currentBook.getTitle());

        //Picasso.with(this).load(currentBook.getCover()).into(cover);
        setSupportActionBar(toolbar);
        this.zoomIn = findViewById(R.id.zoomIn);
        this.startDate = findViewById(R.id.startDate);
        this.endDate = findViewById(R.id.endDate);
        this.etReadingStatus = findViewById(R.id.etReadingStatus);
        this.ratingBar = findViewById(R.id.ratingBar);
        this.summary = findViewById(R.id.summary);
        this.author = findViewById(R.id.author);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });



        loadData();
        buttonHandler();

    }

    public void buttonHandler(){
        zoomIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CheckBook.this, Cover.class);
                intent.putExtra("cover", currentBook.getCover());
                startActivity(intent);

            }
        });
    }

    public void loadData(){

        startDate.setText(this.getResources().getString(R.string.started)+" "+currentBook.getStartDate());
        author.setText(this.getResources().getString(R.string.by)+" "+currentBook.getAuthor());
        int status = currentBook.getReadingStatus();
        String statusList[] = this.getResources().getStringArray(R.array.readingStatus);
        switch(status){
            case 1:
                etReadingStatus.setText(statusList[0]);
                break;
            case 2:
                etReadingStatus.setText(statusList[1]);
                break;
            case 3:
                etReadingStatus.setText(statusList[2]);
                break;
            case 4:
                etReadingStatus.setText(statusList[3]);
                break;
        }

        int statusR = currentBook.getReadingStatus();
        if(statusR<3){
            endDate.setVisibility(View.GONE);
            ratingBar.setVisibility(View.GONE);
        }
        DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
        String date = df.format(Calendar.getInstance().getTime());
        endDate.setText(this.getResources().getString(R.string.ended)+" "+date);
        ratingBar.setRating(currentBook.getRating());
    }

    public void loadExampleBook(){
        Bitmap cover = null;
        currentBook = new Book(1, "El Señor de los Anillos", "J.R.R.Tolkien",cover, 3,"1/1/2018", "", 4, "Pasan cosas.");
    }
}
