package iezv.jmm.mybookshelfproject.Book;


import android.content.Context;
import android.content.res.Resources;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

import iezv.jmm.mybookshelfproject.R;
import iezv.jmm.mybookshelfproject.Book.Book;

public class BookAdapter extends  RecyclerView.Adapter <BookAdapter.MyViewHolder> {

    private List<Book> myBooks;
    private Context context;


    public BookAdapter(List<Book> myBooks, Context context){
        this.myBooks = myBooks;
        this.context = context;
    }

    class MyViewHolder extends RecyclerView.ViewHolder{
        TextView autor;
        TextView titulo;
        public MyViewHolder(@NonNull View itemView){
            super(itemView);
            autor = itemView.findViewById(R.id.autor);
            titulo = itemView.findViewById(R.id.titulo);
        }
    }


    @NonNull
    @Override
    public BookAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i){
        View itemView = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.book_item, viewGroup, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull BookAdapter.MyViewHolder myViewHolder, int position){
        Resources res = myViewHolder.itemView.getContext().getResources();
        myViewHolder.autor.setText(myBooks.get(position).getAuthor());
        myViewHolder.titulo.setText(myBooks.get(position).getTitle());

    }

    @Override
    public int getItemCount(){
        return myBooks.size();
    }

}
