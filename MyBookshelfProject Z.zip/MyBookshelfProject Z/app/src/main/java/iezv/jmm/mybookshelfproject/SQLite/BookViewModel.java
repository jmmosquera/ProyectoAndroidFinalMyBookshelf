package iezv.jmm.mybookshelfproject.SQLite;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;

import java.util.List;

public class BookViewModel extends AndroidViewModel {

    private BookRepository mRepository;

    private LiveData<List<DBLibro>> allBooks;
    private LiveData<List<DBLibro>> allBooksAuth;

    public BookViewModel (Application application) {
        super(application);
        mRepository = new BookRepository(application);
        allBooks = mRepository.getReadingsName();

        allBooksAuth = mRepository.getReadingsAuthor();
    }

    public LiveData<List<DBLibro>> getAllBooks() {
        return allBooks;
    }

    LiveData<List<DBLibro>> getAllBooksAuth() {
        return allBooksAuth;
    }

    public void insert (DBLibro book) {
        mRepository.insert(book);
    }

    LiveData<List<DBLibro>> searchAuthor(String auth) {
        return mRepository.searchByAuthor(auth);
    }

    LiveData<List<DBLibro>> searchTitle(String titl) {
        return mRepository.searchByTitle(titl);
    }
}
