package iezv.jmm.mybookshelfproject.Book;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Parcel;
import android.os.Parcelable;

import java.io.ByteArrayOutputStream;

public class Book implements Parcelable {


    private long id;
    private String idCloud;
    private String title;
    private String author;
    private Bitmap cover;
    private int readingStatus;
    private String startDate;
    private String endDate;
    private int rating;
    private String summary;

    public Book(){}

    public Book(long id, String title, String author, Bitmap cover, int readingStatus, String startDate, String endDate, int rating, String summary) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.cover = cover;
        this.readingStatus = readingStatus;
        this.startDate = startDate;
        this.endDate = endDate;
        this.rating = rating;
        this.summary = summary;
    }

    protected Book(Parcel in) {
        id = in.readLong();
        idCloud = in.readString();
        title = in.readString();
        author = in.readString();
        cover = in.readParcelable(Bitmap.class.getClassLoader());
        readingStatus = in.readInt();
        startDate = in.readString();
        endDate = in.readString();
        rating = in.readInt();
        summary = in.readString();
    }

    public static final Creator<Book> CREATOR = new Creator<Book>() {
        @Override
        public Book createFromParcel(Parcel in) {
            return new Book(in);
        }

        @Override
        public Book[] newArray(int size) {
            return new Book[size];
        }
    };

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public Bitmap getCover() {
        return cover;
    }

    public byte[] getCoverByteArray(){
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        this.cover.compress(Bitmap.CompressFormat.PNG, 100, bos);
        return bos.toByteArray();
    }

    public void setCover(Bitmap cover) {
        this.cover = cover;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public int getReadingStatus() {
        return readingStatus;
    }

    public void setReadingStatus(int readingStatus) {
        this.readingStatus = readingStatus;
    }

    public String getIdCloud() {
        return idCloud;
    }

    public void setIdCloud(String idCloud) {
        this.idCloud = idCloud;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeLong(id);
        dest.writeString(idCloud);
        dest.writeString(title);
        dest.writeString(author);
        dest.writeParcelable(cover, flags);
        dest.writeInt(readingStatus);
        dest.writeString(startDate);
        dest.writeString(endDate);
        dest.writeInt(rating);
        dest.writeString(summary);
    }
}
