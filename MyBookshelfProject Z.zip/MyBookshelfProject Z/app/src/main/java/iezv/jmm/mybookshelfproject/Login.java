package iezv.jmm.mybookshelfproject;


import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

public class Login extends AppCompatActivity {

    EditText userInput;
    EditText passInput;
    Button btn;
    TextView txterror;

    private FirebaseAuth firebaseAuth;
    private FirebaseUser firebaseUser;
    private FirebaseDatabase firebaseDatabase;
    private DatabaseReference databaseReference;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        firebaseAuth = FirebaseAuth.getInstance();
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference();

        userInput = findViewById(R.id.tvusername);
        passInput = findViewById(R.id.tvPass);
        btn = findViewById(R.id.loginbtn);
        txterror = findViewById(R.id.errmsg);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick (View v) {

                if(signIn(userInput.getText().toString(), passInput.getText().toString())){
                    Intent maIntent = new Intent(Login.this, MainActivity.class);
                    startActivity(maIntent);
                }else{
                    txterror.setText("Incorrect username or password");
                }

            }
        });



    }

    private boolean signIn(String email, String password) {
        final boolean[] succ = {false};
        firebaseAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(
                new OnCompleteListener<AuthResult>() {

                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            firebaseUser = firebaseAuth.getCurrentUser();
                            succ[0] = true;
                        } else {
                            Log.v("TAG", task.getException().toString() );
                            succ[0] = false;
                        }
                    }
                });
        return succ[0];
    }

    private void createUser(String email, String password) {
        firebaseAuth.createUserWithEmailAndPassword(email, password).
                addOnCompleteListener(this,
                        new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    firebaseUser = firebaseAuth.getCurrentUser();
                                    firebaseUser = task.getResult().getUser();
                                } else {
                                    Log.v("TAG", task.getException().toString());
                                }
                            }
                        });
    }

    private void saveUser(FirebaseUser user) {
        Map<String, Object> saveUser = new HashMap<>();
        saveUser.put("/user/" + user.getUid(), user.getEmail());
        databaseReference.updateChildren(saveUser).
                addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            Log.v("TAG", task.getResult().toString());
                        } else {
                            Log.v("TAG", task.getException().toString());
                        }
                    }
                });
    }
}
