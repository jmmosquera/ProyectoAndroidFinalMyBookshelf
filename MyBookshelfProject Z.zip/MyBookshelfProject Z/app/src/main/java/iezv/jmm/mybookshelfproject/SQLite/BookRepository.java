package iezv.jmm.mybookshelfproject.SQLite;

import android.app.Application;
import android.arch.lifecycle.LiveData;
import android.os.AsyncTask;

import java.util.List;

public class BookRepository {

    private static DAOLibro mDao;
    private LiveData<List<DBLibro>> mBooksByTitle;
    private LiveData<List<DBLibro>> mBooksByAuthor;

    private LiveData<List<DBLibro>> searchResult;

    BookRepository (Application application) {
        BookRoomDataBase db = BookRoomDataBase.getDatabase(application);
        mDao = db.Dao();
        mBooksByTitle = mDao.getReadingsByName();
        mBooksByAuthor = mDao.getReadingsByAuthor();
    }

    LiveData<List<DBLibro>> getReadingsName(){
        return mBooksByTitle;
    }

    LiveData<List<DBLibro>> getReadingsAuthor(){
        return mBooksByAuthor;
    }

    LiveData<List<DBLibro>> searchByAuthor( String author) {
        return mDao.searchByAuthor(author);
    }

    LiveData<List<DBLibro>> searchByTitle( String title) {
        return mDao.searchByTitle(title);
    }

    static boolean exists (int checkId){
        return !mDao.searchById(checkId).isEmpty();
    }




    public void insert(DBLibro... book) {
        new insertAsyncTask(mDao).execute(book);
    }

    private static class insertAsyncTask extends AsyncTask<DBLibro, Void, Void> {

        private DAOLibro mAsyncTaskDao;

        insertAsyncTask(DAOLibro dao) {
            mAsyncTaskDao = dao;
        }

        @Override
        protected Void doInBackground(final DBLibro... params) {

            for (DBLibro book : params){
                if(book.getBid() != 0){
                    mDao.updateDB(book.getBid(), book.getTitle(), book.getAuthor(), book.getCover(), book.getSummary(), book.getStartDate(), book.getEndDate(), book.getReadingStatus(), book.getRating());
                }else{
                    mAsyncTaskDao.insert(book);
                }
            }
            return null;
        }
    }
}
