package iezv.jmm.mybookshelfproject.Book;

import android.app.Dialog;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.Spinner;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Calendar;

import iezv.jmm.mybookshelfproject.Book.DatePicker;
import iezv.jmm.mybookshelfproject.R;
import iezv.jmm.mybookshelfproject.SQLite.BookViewModel;
import iezv.jmm.mybookshelfproject.SQLite.BooksManager;
import iezv.jmm.mybookshelfproject.SQLite.DBLibro;
import iezv.jmm.mybookshelfproject.SQLite.Helper;


public class AddBook extends AppCompatActivity {

    private android.support.design.widget.TextInputEditText title;
    private android.support.design.widget.TextInputLayout titleLayout;
    private android.support.design.widget.TextInputEditText author;
    private android.support.design.widget.TextInputLayout authorLayout;
    private android.widget.Spinner readingStatus;
    private android.widget.ImageView uploadCover;
    private android.support.design.widget.TextInputEditText summary;
    private android.widget.Button saveBook;
    private android.widget.ImageButton imageButton;
    private android.support.design.widget.TextInputEditText startReading;
    private android.support.design.widget.TextInputLayout startReadingLayout;
    private android.support.design.widget.TextInputEditText endReading;
    private android.support.design.widget.TextInputLayout endReadingLayout;
    private int selected = 0;
    private Dialog rateBook;
    private RatingBar rateBookRatingbar;
    int rating;
    Uri coverUri;
    Bitmap cover = null;
    String coverPath;
    Helper helper = new Helper(AddBook.this);
    BooksManager manager = new BooksManager(AddBook.this);

    private DBLibro book;
    private DBLibro editableBook;
    private BookViewModel BVM;
    private static final int LOAD_IMAGE_CODE = 42;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_book);
        this.endReadingLayout = findViewById(R.id.endReadingLayout);
        this.endReading = findViewById(R.id.endReading);
        this.startReadingLayout = findViewById(R.id.startReadingLayout);
        this.startReading = findViewById(R.id.startReading);
        this.saveBook = findViewById(R.id.saveBook);
        this.summary = findViewById(R.id.summary);
        this.uploadCover = findViewById(R.id.uploadCover);
        this.readingStatus = findViewById(R.id.readingStatus);
        this.authorLayout = findViewById(R.id.authorLayout);
        this.author = findViewById(R.id.author);
        this.titleLayout = findViewById(R.id.titleLayout);
        this.title = findViewById(R.id.title);
        this.imageButton = findViewById(R.id.imageButton);


        BVM = ViewModelProviders.of(this).get(BookViewModel.class);


        if(getIntent().getExtras() == null){
            newBook();
        }else {
            Bundle data = getIntent().getExtras();
            editableBook = data.getParcelable("book");
            chargeBook();
        }


    }

    public void buttonHandlerSetA(){

        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("image/*");
                startActivityForResult(intent, LOAD_IMAGE_CODE);
            }
        });

        readingStatus.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selected = readingStatus.getSelectedItemPosition();
                if(selected>1){
                    endReadingLayout.setVisibility(View.VISIBLE);
                    final Calendar c = Calendar.getInstance();
                    int year = c.get(Calendar.YEAR);
                    int month = c.get(Calendar.MONTH);
                    int day = c.get(Calendar.DAY_OF_MONTH);
                    String date = day+"/"+month+"/"+year;
                    endReading.setText(date);
                }else{
                    endReadingLayout.setVisibility(View.INVISIBLE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        saveBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(selected>1){

                    rateBook = new Dialog(AddBook.this, R.style.FullHeightDialog);
                    rateBook.setContentView(R.layout.rate_book);
                    rateBook.setCancelable(true);


                    Button rateBookButton = rateBook.findViewById(R.id.rateBookButton);

                    rateBookRatingbar = rateBook.findViewById(R.id.rateBookRatingbar);
                    rating = Math.round(rateBookRatingbar.getRating());


                    rateBookButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            rating = Math.round(rateBookRatingbar.getRating());

                            DBLibro book = new DBLibro(0, title.getText().toString(), author.getText().toString(), coverPath, startReading.getText().toString(), endReading.getText().toString(), summary.getText().toString(), selected,  rating);
                            if(editableBook!=null){
                                book.setBid(editableBook.getBid());
                                if(book.getCover()==null){
                                    book.setCover(editableBook.getCover());
                                }
                                storeBook(book);
                                rateBook.dismiss();
                                Intent returnIntent = new Intent();
                                setResult(CheckBook.RESULT_OK,returnIntent);
                                finish();
                            }else{
                                storeBook(book);
                                rateBook.dismiss();

                                finish();
                            }

                        }
                    });
                    rateBook.show();

                }else{
                    DBLibro book = new DBLibro(0, title.getText().toString(), author.getText().toString(), coverPath, startReading.getText().toString(), endReading.getText().toString(), summary.getText().toString(),selected,  0);
                    if(editableBook!=null){
                        if(book.getCover()==null){
                            book.setCover(editableBook.getCover());
                        }
                        book.setBid(editableBook.getBid());
                    }
                    storeBook(book);
                    Intent returnIntent = new Intent();
                    setResult(CheckBook.RESULT_OK,returnIntent);
                    finish();
                }



            }
        });

        startReading.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DialogFragment datepicker = new DatePicker();
                datepicker.show(getSupportFragmentManager(), "datepicker1");

            }
        });

        endReading.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DialogFragment datepicker = new DatePicker();
                datepicker.show(getSupportFragmentManager(), "datepicker2");

            }
        });
    }

    public void storeBook(DBLibro book){
        BVM.insert(book);
    }

    public void getDate(String date){
        startReading.setText(date);
        startReading.setTextColor(getResources().getColor(R.color.colorAccent));
    }

    public void getEndDate(String date){
        endReading.setText(date);
        endReading.setTextColor(getResources().getColor(R.color.colorAccent));
    }

    public void changeColorBriefly(){
        int editTextColour = 0;
        TypedArray themeArray = AddBook.this.getTheme().obtainStyledAttributes(new int[] {android.R.attr.editTextColor});
        try {
            int index = 0;
            int defaultColourValue = 0;
            editTextColour = themeArray.getColor(index, defaultColourValue);
        }
        finally
        {
            themeArray.recycle();
        }

        int counter = 200;

        try{
            do{

                counter--;
                SystemClock.sleep(1);
            }while(counter!=0);
        }catch(Exception e){
            e.toString();
        }finally {
            startReading.setTextColor(editTextColour);
            endReading.setTextColor(editTextColour);
        }
    }


    public void newBook(){
        buttonHandlerSetA();
        final Calendar c = Calendar.getInstance();
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH);
        int day = c.get(Calendar.DAY_OF_MONTH);
        String date = day+"/"+month+"/"+year;
        startReading.setText(date);
    }

    public void chargeBook(){
        title.setText(editableBook.getTitle());
        author.setText(editableBook.getAuthor());
        readingStatus.setSelection(editableBook.getReadingStatus()-1);
        Picasso.with(AddBook.this).load(Uri.parse("file://"+editableBook.getCover())).into(uploadCover);
        summary.setText(editableBook.getSummary());
        startReading.setText(editableBook.getStartDate());
        endReading.setText(editableBook.getEndDate());
        buttonHandlerSetA();
    }

    private String saveToInternalStorage(Bitmap bitmapImage){
        ContextWrapper cw = new ContextWrapper(getApplicationContext());

        File directory = cw.getDir("imageDir", Context.MODE_PRIVATE);

        //File directory = Environment.getExternalStorageDirectory();

        String cPath = "/profile"+System.currentTimeMillis()/10000+".jpg";
        File mypath=new File(directory,cPath);

        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(mypath);
            bitmapImage.compress(Bitmap.CompressFormat.PNG, 100, fos);
        } catch (Exception e) {
            e.printStackTrace();
        } /*finally {
            try {
                fos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }*/
        return directory.getAbsolutePath()+cPath;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == this.RESULT_CANCELED) {
            return;
        }
        if (requestCode == LOAD_IMAGE_CODE) {
            if (data != null) {
                coverUri = data.getData();
                Picasso.with(AddBook.this).load(coverUri).into(uploadCover);
                try {
                    cover = MediaStore.Images.Media.getBitmap(this.getContentResolver(), coverUri);
                    coverPath = saveToInternalStorage(cover);
                    Toast.makeText(AddBook.this, "Image Saved!", Toast.LENGTH_SHORT).show();
                    //imageview.setImageBitmap(bitmap);

                } catch (IOException e) {
                    e.printStackTrace();
                    Toast.makeText(AddBook.this, "Failed!", Toast.LENGTH_SHORT).show();
                }
            }

        }

    }
}
